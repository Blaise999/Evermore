const express = require("express");

const auth = require("../middleware/auth");
const requireRole = require("../middleware/requireRole");
const { asyncHandler, AppError } = require("../middleware/error");

const User = require("../models/User");
const PatientAccount = require("../models/PatientAccount");
const Appointment = require("../models/Appointment");
const Record = require("../models/Record");
const Invoice = require("../models/Invoice");
const PaymentRequest = require("../models/PaymentRequest");
const AuditLog = require("../models/AuditLog");

const { makeRequestRef } = require("../utils/refs");
const { auditLog } = require("../utils/audit");

// ---------------------------
// CareFlex (Option A) helpers
// ---------------------------
function n2(num) {
  const n = Number(num);
  if (!Number.isFinite(n)) return 0;
  return Math.round(n * 100) / 100;
}

function invoiceBalanceDue(inv) {
  const total = n2(inv?.total);
  const covered = n2(inv?.coveredAmount);
  return Math.max(0, n2(total - covered));
}

async function computeOutstandingOwedEUR(userId) {
  const docs = await Invoice.find({ userId, status: { $ne: "void" } }).select("total coveredAmount status").lean();
  let owed = 0;
  for (const inv of docs) {
    const covered = n2(inv.coveredAmount);
    const total = n2(inv.total);
    const effectiveCovered = inv.status === "paid" ? Math.max(covered, total) : covered;
    owed += Math.max(0, n2(total - effectiveCovered));
  }
  return n2(owed);
}

async function applyCareflexRepaymentOldestFirst(userId, amountEUR) {
  let remaining = n2(amountEUR);
  if (remaining <= 0) return { applied: [], remaining: 0 };

  const invoices = await Invoice.find({ userId, status: { $ne: "void" } }).sort({ issuedAt: 1 });
  const applied = [];

  for (const inv of invoices) {
    if (remaining <= 0) break;

    if (!Number.isFinite(Number(inv.coveredAmount))) inv.coveredAmount = 0;

    if (inv.status === "paid") {
      inv.coveredAmount = Math.max(n2(inv.coveredAmount), n2(inv.total));
      await inv.save();
      continue;
    }

    const due = invoiceBalanceDue(inv);
    if (due <= 0) {
      inv.status = "paid";
      inv.paidAt = inv.paidAt || new Date();
      inv.coveredAmount = Math.max(n2(inv.coveredAmount), n2(inv.total));
      await inv.save();
      continue;
    }

    const take = Math.min(due, remaining);
    inv.coveredAmount = n2(n2(inv.coveredAmount) + take);
    remaining = n2(remaining - take);

    if (invoiceBalanceDue(inv) <= 0) {
      inv.status = "paid";
      inv.paidAt = new Date();
      inv.coveredAmount = Math.max(n2(inv.coveredAmount), n2(inv.total));
    }

    await inv.save();
    applied.push({ invoiceId: inv._id, invoiceNo: inv.invoiceNo, amount: take });
  }

  return { applied, remaining };
}

const router = express.Router();

router.use(auth);
router.use(requireRole("admin"));

/**
 * ADMIN: list users
 */
router.get(
  "/users",
  asyncHandler(async (req, res) => {
    const page = Math.max(1, Number(req.query.page || 1));
    const limit = Math.min(50, Math.max(1, Number(req.query.limit || 20)));
    const q = String(req.query.q || "").trim();

    const filter = q
      ? {
          $or: [
            { email: { $regex: q, $options: "i" } },
            { name: { $regex: q, $options: "i" } },
            { hospitalId: { $regex: q, $options: "i" } },
          ],
        }
      : {};

    const [items, total] = await Promise.all([
      User.find(filter).sort({ createdAt: -1 }).skip((page - 1) * limit).limit(limit),
      User.countDocuments(filter),
    ]);

    res.json({
      ok: true,
      page,
      limit,
      total,
      users: items.map((u) => u.safe()),
    });
  })
);

/**
 * ADMIN: get a user by id (full bundle)
 */
router.get(
  "/users/:id",
  asyncHandler(async (req, res) => {
    const user = await User.findById(req.params.id);
    if (!user) throw new AppError("User not found", 404);

    const [account, appointments, records, invoices, payments] = await Promise.all([
      PatientAccount.findOne({ userId: user._id }).lean(),
      Appointment.find({ userId: user._id }).sort({ scheduledAt: 1 }).lean(),
      Record.find({ userId: user._id }).sort({ recordedAt: -1 }).lean(),
      Invoice.find({ userId: user._id }).sort({ issuedAt: -1 }).lean(),
      PaymentRequest.find({ userId: user._id }).sort({ createdAt: -1 }).lean(),
    ]);

    res.json({
      ok: true,
      user: user.safe(),
      account: account || null,
      appointments,
      records,
      invoices,
      payments,
    });
  })
);

/**
 * ADMIN: edit money stuff (balances / credit limit / amount owed / credit score)
 */
router.patch(
  "/users/:id/account",
  asyncHandler(async (req, res) => {
    const userId = req.params.id;

    const account = await PatientAccount.findOne({ userId });
    if (!account) throw new AppError("Account not found", 404);

    const before = account.toObject();

    const {
      balance,
      creditLimit,
      amountOwed,
      creditScore,
      owedDueAt,
      currency,
      notes,
    } = req.body || {};

    if (balance !== undefined) account.balance = Number(balance);
    if (creditLimit !== undefined) account.creditLimit = Number(creditLimit);
    if (amountOwed !== undefined) account.amountOwed = Number(amountOwed);
    if (creditScore !== undefined) account.creditScore = Number(creditScore);
    if (currency !== undefined) account.currency = String(currency);
    if (notes !== undefined) account.notes = notes ? String(notes) : null;

    if (owedDueAt !== undefined) {
      account.owedDueAt = owedDueAt ? new Date(owedDueAt) : null;
    }

    await account.save();

    await auditLog({
      actorId: req.user.id,
      actorRole: req.user.role,
      action: "ADMIN_ACCOUNT_UPDATE",
      targetModel: "PatientAccount",
      targetId: String(account._id),
      before,
      after: account.toObject(),
      ip: req.ip,
      userAgent: req.headers["user-agent"],
    });

    res.json({ ok: true, account });
  })
);

/**
 * ADMIN: edit appointments
 */
router.patch(
  "/appointments/:appointmentId",
  asyncHandler(async (req, res) => {
    const appt = await Appointment.findById(req.params.appointmentId);
    if (!appt) throw new AppError("Appointment not found", 404);

    const before = appt.toObject();

    const { department, doctorName, scheduledAt, status, reason, notes } = req.body || {};

    if (department !== undefined) appt.department = String(department);
    if (doctorName !== undefined) appt.doctorName = doctorName ? String(doctorName) : null;
    if (scheduledAt !== undefined) appt.scheduledAt = new Date(scheduledAt);
    if (status !== undefined) appt.status = String(status);
    if (reason !== undefined) appt.reason = reason ? String(reason) : null;
    if (notes !== undefined) appt.notes = notes ? String(notes) : null;

    await appt.save();

    await auditLog({
      actorId: req.user.id,
      actorRole: req.user.role,
      action: "ADMIN_APPOINTMENT_UPDATE",
      targetModel: "Appointment",
      targetId: String(appt._id),
      before,
      after: appt.toObject(),
      ip: req.ip,
      userAgent: req.headers["user-agent"],
    });

    res.json({ ok: true, appointment: appt });
  })
);

/**
 * ADMIN: edit hospital reports (records)
 */
router.patch(
  "/records/:recordId",
  asyncHandler(async (req, res) => {
    const record = await Record.findById(req.params.recordId);
    if (!record) throw new AppError("Record not found", 404);

    const before = record.toObject();

    const { type, title, summary, data, recordedAt, clinician, status } = req.body || {};
    if (type !== undefined) record.type = String(type);
    if (title !== undefined) record.title = String(title);
    if (summary !== undefined) record.summary = summary ? String(summary) : null;
    if (data !== undefined) record.data = data;
    if (recordedAt !== undefined) record.recordedAt = new Date(recordedAt);
    if (clinician !== undefined) record.clinician = clinician ? String(clinician) : null;
    if (status !== undefined) record.status = String(status);

    await record.save();

    await auditLog({
      actorId: req.user.id,
      actorRole: req.user.role,
      action: "ADMIN_RECORD_UPDATE",
      targetModel: "Record",
      targetId: String(record._id),
      before,
      after: record.toObject(),
      ip: req.ip,
      userAgent: req.headers["user-agent"],
    });

    res.json({ ok: true, record });
  })
);

/**
 * ADMIN: list payment requests (default pending)
 */
router.get(
  "/payments",
  asyncHandler(async (req, res) => {
    const status = String(req.query.status || "pending");
    const items = await PaymentRequest.find({ status }).sort({ createdAt: -1 }).limit(200).lean();
    res.json({ ok: true, payments: items });
  })
);

/**
 * ADMIN: approve payment request
 * - marks paymentRequest approved
 * - if linked to invoice: marks invoice paid
 * - updates patient account (reduce amountOwed OR increase balance; sponsor-demo logic)
 */
router.post(
  "/payments/:paymentId/approve",
  asyncHandler(async (req, res) => {
    const pr = await PaymentRequest.findById(req.params.paymentId);
    if (!pr) throw new AppError("Payment request not found", 404);
    if (pr.status !== "pending") throw new AppError("Payment request is not pending", 400);

    const account = await PatientAccount.findOne({ userId: pr.userId });
    if (!account) throw new AppError("Patient account not found", 404);

    const beforePR = pr.toObject();

    pr.status = "approved";
    pr.reviewedBy = req.user.id;
    pr.reviewedAt = new Date();
    pr.adminNote = req.body?.adminNote ? String(req.body.adminNote) : null;
    await pr.save();

    // Apply effects based on payment kind
    let invoice = null;
    let allocation = null;

    // 1) Single invoice payment
    if (pr.kind === "invoice_payment" && pr.invoiceId) {
      invoice = await Invoice.findById(pr.invoiceId);
      if (!invoice) throw new AppError("Invoice not found", 404);
      if (invoice.status !== "issued") throw new AppError("Invoice is not payable", 400);

      invoice.status = "paid";
      invoice.paidAt = new Date();
      invoice.coveredAmount = Math.max(n2(invoice.coveredAmount), n2(invoice.total));
      await invoice.save();
    }

    // 2) CareFlex repayment (Option A): allocate oldest-first
    if (pr.kind === "careflex_repayment") {
      allocation = await applyCareflexRepaymentOldestFirst(pr.userId, pr.amount);
      pr.applied = allocation.applied;
      pr.meta = Object.assign({}, pr.meta || {}, {
        remaining: allocation.remaining,
        settledAt: new Date().toISOString(),
      });
      await pr.save();
    }

    // 3) Optional: topups increase balance
    const beforeAcc = account.toObject();
    const amt = n2(pr.amount);
    if (pr.kind === "topup") {
      account.balance = n2(n2(account.balance) + amt);
    }

    // Keep patient account in sync (derived from invoices)
    account.currency = "EUR";
    if (!Number.isFinite(Number(account.creditLimit)) || Number(account.creditLimit) <= 0) account.creditLimit = 5000;
    account.amountOwed = await computeOutstandingOwedEUR(pr.userId);

    await account.save();

    await auditLog({
      actorId: req.user.id,
      actorRole: req.user.role,
      action: "ADMIN_PAYMENT_APPROVE",
      targetModel: "PaymentRequest",
      targetId: String(pr._id),
      before: beforePR,
      after: pr.toObject(),
      ip: req.ip,
      userAgent: req.headers["user-agent"],
    });

    await auditLog({
      actorId: req.user.id,
      actorRole: req.user.role,
      action: "ADMIN_ACCOUNT_AUTO_UPDATE_AFTER_PAYMENT_APPROVE",
      targetModel: "PatientAccount",
      targetId: String(account._id),
      before: beforeAcc,
      after: account.toObject(),
      ip: req.ip,
      userAgent: req.headers["user-agent"],
    });

    res.json({
      ok: true,
      payment: pr,
      invoice: invoice ? invoice.toObject() : null,
      account: account.toObject(),
      careflex: {
        currency: "EUR",
        limit: n2(account.creditLimit ?? 5000),
        owed: n2(account.amountOwed ?? 0),
        available: n2((account.creditLimit ?? 5000) - (account.amountOwed ?? 0)),
      },
      applied: allocation ? allocation.applied : [],
    });
  })
);

/**
 * ADMIN: decline payment request
 */
router.post(
  "/payments/:paymentId/decline",
  asyncHandler(async (req, res) => {
    const pr = await PaymentRequest.findById(req.params.paymentId);
    if (!pr) throw new AppError("Payment request not found", 404);
    if (pr.status !== "pending") throw new AppError("Payment request is not pending", 400);

    const before = pr.toObject();

    pr.status = "declined";
    pr.reviewedBy = req.user.id;
    pr.reviewedAt = new Date();
    pr.adminNote = req.body?.adminNote ? String(req.body.adminNote) : "Declined";
    await pr.save();

    await auditLog({
      actorId: req.user.id,
      actorRole: req.user.role,
      action: "ADMIN_PAYMENT_DECLINE",
      targetModel: "PaymentRequest",
      targetId: String(pr._id),
      before,
      after: pr.toObject(),
      ip: req.ip,
      userAgent: req.headers["user-agent"],
    });

    res.json({ ok: true, payment: pr });
  })
);

/**
 * ADMIN: seed anything for a user (appointments / records / invoices)
 * Body:
 * {
 *   appointments: true,
 *   records: true,
 *   invoices: true,
 *   count: 3
 * }
 */
router.post(
  "/users/:id/seed",
  asyncHandler(async (req, res) => {
    const user = await User.findById(req.params.id);
    if (!user) throw new AppError("User not found", 404);

    const count = Math.min(20, Math.max(1, Number(req.body?.count || 3)));
    const flags = {
      appointments: req.body?.appointments !== false,
      records: req.body?.records !== false,
      invoices: req.body?.invoices !== false,
    };

    const created = { appointments: 0, records: 0, invoices: 0 };

    if (flags.appointments) {
      const docs = [];
      for (let i = 0; i < count; i++) {
        const d = new Date(Date.now() + (i + 1) * 24 * 60 * 60 * 1000);
        d.setHours(10 + i, 0, 0, 0);
        docs.push({
          userId: user._id,
          department: ["Cardiology", "General Practice", "Radiology", "Dermatology"][i % 4],
          doctorName: ["Dr. Adebayo", "Dr. Musa", "Dr. Okafor", "Dr. Smith"][i % 4],
          scheduledAt: d,
          status: "scheduled",
          reason: "Routine checkup",
          notes: "Seeded appointment",
        });
      }
      await Appointment.insertMany(docs);
      created.appointments = docs.length;
    }

    if (flags.records) {
      const docs = [];
      for (let i = 0; i < count; i++) {
        docs.push({
          userId: user._id,
          type: ["consultation", "lab", "radiology"][i % 3],
          title: ["Consultation Note", "Lab Report", "Radiology Report"][i % 3],
          summary: "Seeded record for demo.",
          clinician: ["Dr. Adebayo", "Dr. Musa", "Dr. Okafor"][i % 3],
          status: "final",
          data: {
            vitals: { bp: "120/80", temp: "36.7C", pulse: 72 },
            findings: "Normal",
            recommendation: "Hydrate, rest, follow-up if symptoms persist.",
          },
          recordedAt: new Date(Date.now() - i * 24 * 60 * 60 * 1000),
        });
      }
      await Record.insertMany(docs);
      created.records = docs.length;
    }

    if (flags.invoices) {
      for (let i = 0; i < count; i++) {
        const issuedAt = new Date(Date.now() - i * 24 * 60 * 60 * 1000);
        const dueDate = new Date(Date.now() + 14 * 24 * 60 * 60 * 1000);

        // Create a matching appointment (Invoice schema requires appointmentId)
        const appt = await Appointment.create({
          userId: user._id,
          department: ["General Practice", "Cardiology", "Radiology", "Dermatology"][i % 4],
          doctorName: ["Dr. Adebayo", "Dr. Musa", "Dr. Okafor", "Dr. Smith"][i % 4],
          scheduledAt: issuedAt,
          status: "completed",
          reason: "Seeded appointment for invoice",
          notes: "Seeded",
        });

        const lineItems = [
          { code: "CONS", description: "Consultation", qty: 1, unitPrice: 120, amount: 120 },
          { code: "LAB", description: "Lab work", qty: 1, unitPrice: 80, amount: 80 },
        ];

        const subtotal = lineItems.reduce((s, it) => s + Number(it.amount || 0), 0);
        const tax = 0;
        const total = subtotal + tax;

        await Invoice.create({
          invoiceNo: makeRequestRef("INV"),
          userId: user._id,
          hospitalId: String(user.hospitalId || "EVM").trim(),
          appointmentId: appt._id,
          currency: "EUR",
          status: "issued",
          issuedAt,
          dueDate,
          paidAt: null,
          coveredAmount: 0,
          items: lineItems,
          subtotal,
          tax,
          total,
          notes: "Seeded invoice for demo.",
        });

        created.invoices += 1;
      }
    }

    await auditLog({
      actorId: req.user.id,
      actorRole: req.user.role,
      action: "ADMIN_SEED_USER_DATA",
      targetModel: "User",
      targetId: String(user._id),
      after: { created, flags, count },
      ip: req.ip,
      userAgent: req.headers["user-agent"],
    });

    res.json({ ok: true, created });
  })
);

/**
 * ADMIN: audit logs (optional useful panel)
 */
router.get(
  "/audit",
  asyncHandler(async (req, res) => {
    const limit = Math.min(200, Math.max(1, Number(req.query.limit || 50)));
    const logs = await AuditLog.find().sort({ createdAt: -1 }).limit(limit).lean();
    res.json({ ok: true, logs });
  })
);

module.exports = router;
